Alliedmods topic - https://forums.alliedmods.net/showthread.php?p=2659021
